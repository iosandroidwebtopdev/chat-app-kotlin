package edu_chat.android.com.edu_chat.controller.chat.chatinfo;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionButton;
import chat.edu.edu_chat.R.id;
import chat.edu.edu_chat.R.layout;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import edu_chat.android.com.edu_chat.adapter.chat.chatinfo.ChatResourceAdapter;
import edu_chat.android.com.edu_chat.model.ChatResource;
import edu_chat.android.com.edu_chat.view.DividerItemDecoration;

/**
 * Created by yuandali on 6/20/16.
 * Edu.Chat Inc.
 */

public class PlannerFragment extends Fragment {

    @Nullable
    @BindView(id.addevent) FloatingActionButton addEvent;
    @BindView(id.eventslistview) RecyclerView eventsListView;

    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {
        final View view = inflater.inflate(layout.fragment_planner, container, false);
        ButterKnife.bind(this, view);

        this.updateListView();

        this.addEvent.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                Toast.makeText(PlannerFragment.this.getActivity(), "Coming Soon!!", Toast
                        .LENGTH_SHORT).show();
            }
        });
        return view;
    }

    private void updateListView() {
//        final List<ChatResource> eventList = ((ChatinfoActivity) this.getActivity()).getEventList();
//
//        final ChatResourceAdapter adapter = new ChatResourceAdapter(this.getActivity(), eventList);
//
//        this.eventsListView.setHasFixedSize(false);
//        this.eventsListView.addItemDecoration(new DividerItemDecoration(this.getActivity()));
//        this.eventsListView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
//        this.eventsListView.setAdapter(adapter);
    }
}
