/*
        final SpannableString sssignup = new SpannableString("Don't have an account? Sign Up!");
        final SpannableString ssforgot = new SpannableString(this.forgotPassword.getText()
                                                                     .toString());
        final ClickableSpan forgotspan = new ClickableSpan() {
            @Override
            public void onClick(final View view) {
                Toast.makeText(LoginActivity.this.getApplicationContext(), "coming soon!", Toast
                        .LENGTH_SHORT).show();
            }
        };
        final ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(final View textView) {
                final Intent intent = new Intent(
                        LoginActivity.this.getApplicationContext(),
                        SignUpActivity.class
                );
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                LoginActivity.this.getApplication().startActivity(intent);
            }

            @Override
            public void updateDrawState(@NonNull final TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }
        };


        ssforgot.setSpan(forgotspan, 0, 16, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ssforgot.setSpan(new ForegroundColorSpan(Color.BLUE), 0, 16, 0);
        sssignup.setSpan(clickableSpan, 23, 31, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sssignup.setSpan(new UnderlineSpan(), 23, 31, 0);
        sssignup.setSpan(new ForegroundColorSpan(Color.GREEN), 23, 31, 0);

        if (this.signUpTextView != null) {
            this.signUpTextView.setText(sssignup);
        }
        this.forgotPassword.setText(ssforgot);
        this.signUpTextView.setMovementMethod(LinkMovementMethod.getInstance());
        this.forgotPassword.setMovementMethod(LinkMovementMethod.getInstance());
        */


//        this.userEmail.setOnTouchListener(new OnTouchListener() {
//            @Override
//            public boolean onTouch(final View v, final MotionEvent event) {
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (LoginActivity.this.userEmail.getCompoundDrawables()[DRAWABLE_RIGHT] !=
// null) {
//                        if (event.getRawX() >= LoginActivity.this.userEmail.getRight() -
// LoginActivity.this
//                                .userEmail.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds()
// .width()) {
//                            // your action here
//                            LoginActivity.this.userEmail.setText("");
//                            return true;
//                        }
//                    }
//                }
//                return false;
//            }
//        });
//        this.userPass.setOnTouchListener(new OnTouchListener() {
//            @Override
//            public boolean onTouch(final View v, final MotionEvent event) {
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (LoginActivity.this.userPass.getCompoundDrawables()[DRAWABLE_RIGHT] !=
// null) {
//                        if (event.getRawX() >= LoginActivity.this.userPass.getRight() -
// LoginActivity.this.userPass.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width()) {
//                            // your action here
//                            LoginActivity.this.userPass.setText("");
//                            return true;
//                        }
//                    }
//                }
//                return false;
//            }
//        });

//        this.userEmail.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(final CharSequence charSequence,
//                                          final int i,
//                                          final int i1,
//                                          final int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(final CharSequence charSequence,
//                                      final int i,
//                                      final int i1,
//                                      final int i2) {
//                if (LoginActivity.this.userEmail.getText().toString().isEmpty()) {
//                    LoginActivity.this.userEmail.setCompoundDrawablesWithIntrinsicBounds(
//                            0,
//                            0,
//                            0,
//                            0
//                    );
//
//                } else
//                    LoginActivity.this.userEmail.setCompoundDrawablesWithIntrinsicBounds(
//                            0,
//                            0,
//                            drawable.ic_action_navigation_close_inverted,
//                            0
//                    );
//            }
//
//            @Override
//            public void afterTextChanged(final Editable editable) {
//
//            }
//        });
//        this.userPass.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(final CharSequence charSequence,
//                                          final int i,
//                                          final int i1,
//                                          final int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(final CharSequence charSequence,
//                                      final int i,
//                                      final int i1,
//                                      final int i2) {
//                if (LoginActivity.this.userPass.getText().toString().isEmpty()) {
//                    LoginActivity.this.userPass.setCompoundDrawablesWithIntrinsicBounds(
//                            0,
//                            0,
//                            0,
//                            0
//                    );
//
//                } else
//                    LoginActivity.this.userPass.setCompoundDrawablesWithIntrinsicBounds(
//                            0,
//                            0,
//                            drawable.ic_action_navigation_close_inverted,
//                            0
//                    );
//            }
//
//            @Override
//            public void afterTextChanged(final Editable editable) {
//
//            }
//        });


//        this.signUpTextView.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(final View view) {
//                final Intent intent = new Intent(LoginActivity.this.getApplicationContext(),
//                        SignUpActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                LoginActivity.this.getApplication().startActivity(intent);
//            }
//        });

//        signUpTextView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                getApplication().startActivity(intent);
//            }
//        });

// -----
//        userEmail.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                final int DRAWABLE_RIGHT = 2;
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (event.getRawX() >= (userEmail.getRight() - userEmail
// .getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
//                        userEmail.setText("");
//                        return true;
//                    }
//                }
//                return false;
//            }
//        });
//        userPass.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                final int DRAWABLE_RIGHT = 2;
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (event.getRawX() >= (userPass.getRight() - userPass.getCompoundDrawables
// ()[DRAWABLE_RIGHT].getBounds().width())) {
//                        userPass.setText("");
//                        return true;
//                    }
//                }
//                return false;
//            }
//        });

//        this.userPass.setSelection(this.userPass.getText().length());

//        if (this.userEmail.length() > 0) {
//            if (this.prefs.getBoolean("autoLogin", false)) {
//                this.attemptLogin();
//            } else {
//                Log.v(this.getClass().getSimpleName(), "Do not auto login");
//            }
//        }

//        signInBlue.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getActivity().getBaseContext(),"clicked",Toast.LENGTH_SHORT)
// .show();
//                attemptSignup();
//            }
//        });


//        this.googleSignInButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(final View view) {
//                LoginActivity.this.signIn();
//            }
//        });

//        final GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions
//                .DEFAULT_SIGN_IN)
//                .requestEmail()
//                .build();
//
//        this.mGoogleApiClient = new Builder(this)
//                .enableAutoManage(this, this)
//                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
//                .build();
//
//        this.googleSignInButton.setSize(SignInButton.SIZE_STANDARD);
//        this.googleSignInButton.setScopes(gso.getScopeArray());


//    private void showProgressDialog() {
//        if (progressDialog == null) {
//            progressDialog = new ProgressDialog(this);
//            progressDialog.setMessage("Logging In...");
//            progressDialog.setIndeterminate(true);
//        }
////        progressDialog.show();
//    }
//
//    private void hideProgressDialog() {
//        if (progressDialog != null && progressDialog.isShowing()) {
//            progressDialog.hide();
//        }
//    }
//
//    @Override
//    public void onConnectionFailed(@NonNull final ConnectionResult connectionResult) {
//        Log.d("GoogleSignIn", "onConnectionFailed:" + connectionResult);
//    }
//
//    @Override
//    public void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == RC_SIGN_IN) {
//            final GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent
// (data);
//            this.handleSignInResult(result);
//        }
//    }
//
//    @Override
//    public void onStart() {
//        super.onStart();
//        final OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn
//                (this.mGoogleApiClient);
//        if (opr.isDone()) {
//            Log.d("GoogleSignIn", "Got cached sign-in");
//            final GoogleSignInResult result = opr.get();
//            this.handleSignInResult(result);
//        } else {
//            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
//                @Override
//                public void onResult(@NonNull final GoogleSignInResult googleSignInResult) {
//                    LoginActivity.this.handleSignInResult(googleSignInResult);
//                }
//            });
//        }
//    }

//    private void handleSignInResult(@NonNull final GoogleSignInResult result) {
//        Log.d("GoogleSignIn", "handleSignInResult:" + result.isSuccess());
//        if (result.isSuccess()) {
//            final GoogleSignInAccount acct = result.getSignInAccount();
//            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
//            this.updateUI();
//        } else {
//            this.updateUI();
//        }
//    }

//    private void signIn() {
//        final Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(this.mGoogleApiClient);
//        this.startActivityForResult(signInIntent, RC_SIGN_IN);
//    }

//    private void signOut() {
//        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
//                new ResultCallback<Status>() {
//                    @Override
//                    public void onResult(@NonNull Status status) {
//                        updateUI(false);
//                    }
//                });
//    }
//
//    private void revokeAccess() {
//        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(
//                new ResultCallback<Status>() {
//                    @Override
//                    public void onResult(@NonNull Status status) {
//                        updateUI(false);
//                    }
//                });
//    }

//    private void updateUI() {
//        if (signedIn) {
//            Toast.makeText(this, "signedIn", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(this, "Not SignedIn", Toast.LENGTH_SHORT).show();
//        }
//    }

//    @Override
//    public String toString() {
//        return "LoginActivity{" +
//                "userEmail=" + this.userEmail +
//                ", userPass=" + this.userPass +
//                ", signUpTextView=" + this.signUpTextView +
//                ", loginButton=" + this.loginButton +
//                ", buildVersionTextView=" + this.buildVersionTextView +
//                ", forgotPassword=" + this.forgotPassword +
//                ", prefs=" + this.prefs +
//                ", mFirebaseRemoteConfig=" + this.mFirebaseRemoteConfig +
//                "} " + super.toString();
//    }

//    final class MyOnClickListener implements OnClickListener {
//        private final Snackbar snackbar;
//
//        private MyOnClickListener(final Snackbar snackbar) {
//            super();
//            this.snackbar = snackbar;
//        }
//
//        @Override
//        public void onClick(final View v) {
//            this.snackbar.setText("clicked me");
//        }
//    }

