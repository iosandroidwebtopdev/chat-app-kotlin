package edu_chat.android.com.edu_chat.adapter.chat.chatinfo;

import android.app.Activity;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import chat.edu.edu_chat.R.id;
import chat.edu.edu_chat.R.layout;

import java.util.List;

import edu_chat.android.com.edu_chat.model.ChatResource;

/**
 * Created by yuandali on 8/21/16.
 * Edu.Chat Inc.
 */

public class ChatResourceAdapter extends Adapter {

    private final Activity activity;
    private final List<ChatResource> chatResources;

    public ChatResourceAdapter(final Activity activity, final List<ChatResource> chatResources) {
        super();
        this.activity = activity;
        this.chatResources = chatResources;
    }

    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(
                layout.item_chat_resource, parent, false);
        return new ResourceHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ChatResource resource = this.chatResources.get(position);
        final ResourceHolder resourceHolder = (ResourceHolder) holder;
        resourceHolder.setTitle(resource.getTitle());
        resourceHolder.setDateTextView(resource.getDate());
        resourceHolder.setPostedByTextView(resource.getPostedBy());
        resourceHolder.setInfoTextView(resource.getInfo());
        resourceHolder.setCreatedTextView(resource.getCreated());
        resourceHolder.setCommentCount(resource.getCommentCount());
    }

    @Override
    public int getItemCount() {
        return this.chatResources.size();
    }

    private class ResourceHolder extends ViewHolder implements OnClickListener {

        //        private final ImageView imageView;
        private final TextView titleTextView;
        private final TextView dateTextView;
        private final TextView postedByTextView;
        private final TextView resourceInfoTextView;
        private final TextView createdTextView;
        private final TextView commentTextView;

        ResourceHolder(final View itemView) {
            super(itemView);
//            this.imageView = (ImageView) itemView.findViewById(id.imageView);
            this.titleTextView = itemView.findViewById(id.titleTextView);
            this.dateTextView = itemView.findViewById(id.dateTextView);
            this.postedByTextView = itemView.findViewById(id.postedByTextView);
            this.resourceInfoTextView = itemView.findViewById(id.resourceInfoTextView);
            this.createdTextView = itemView.findViewById(id.timeTextView);
            this.commentTextView = itemView.findViewById(id.commentTextView);
            itemView.setOnClickListener(this);
        }

        public void setTitle(final String title) {
            if (this.titleTextView != null) {
                this.titleTextView.setText(title);
            }
        }

        void setDateTextView(final String dateString) {
            if (this.dateTextView != null) {
                this.dateTextView.setText(dateString);
            }
        }

        void setPostedByTextView(final String postedBy) {
            if (this.postedByTextView != null) {
                this.postedByTextView.setText(postedBy);
            }
        }

        void setInfoTextView(final String info) {
            if (this.resourceInfoTextView != null) {
                this.resourceInfoTextView.setText(info);
            }
        }

        void setCreatedTextView(final String created) {
            if (this.createdTextView != null) {
                this.createdTextView.setText(created);
            }
        }

        void setCommentCount(final int commentCount) {
            if (this.commentTextView != null && commentCount > 0) {
                this.commentTextView.setText(commentCount + " comments");
            }
        }

        @Override
        public void onClick(final View v) {
            Toast.makeText(
                    ChatResourceAdapter.this.activity,
                    "Clicked.",
                    Toast.LENGTH_SHORT
            ).show();
        }

        @Override public String toString() {
            return "ResourceHolder{" +
                    "titleTextView=" + this.titleTextView +
                    ", dateTextView=" + this.dateTextView +
                    ", postedByTextView=" + this.postedByTextView +
                    ", resourceInfoTextView=" + this.resourceInfoTextView +
                    ", createdTextView=" + this.createdTextView +
                    ", commentTextView=" + this.commentTextView +
                    "} " + super.toString();
        }
    }
}