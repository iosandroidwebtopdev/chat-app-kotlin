package edu_chat.android.com.edu_chat.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by yuandali on 8/27/16.
 * Edu.Chat Inc.
 */

public class ChatResource {

    private String info = "";
    private int commentCount;
    private String created = "";

    ChatResource() {
        super();
    }

    public String getTitle() {
        return "Title";
    }

    public String getDate() {
        return "Date";
    }

    public String getPostedBy() {
        return "Posted by";
    }

    public String getInfo() {
        return this.info;
    }

    void setInfo(final String info) {
        this.info = info;
    }

    public int getCommentCount() {
        return this.commentCount;
    }

    public void setCommentCount(final int commentCount) {
        this.commentCount = commentCount;
    }

    public String getCreated() {
        return this.created;
    }

    void setCreated(final String createdString) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            final Date date = sdf.parse(createdString.replace("T", " "));
            final SimpleDateFormat out = new SimpleDateFormat("h:mm a, MMM d");
            this.created = out.format(date);
        } catch (final ParseException e) {
            e.printStackTrace();
            this.created = "";
        }
    }
}
