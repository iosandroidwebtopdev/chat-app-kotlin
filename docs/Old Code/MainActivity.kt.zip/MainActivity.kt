package edu_chat.android.com.edu_chat.controller.main

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.design.widget.TabLayout
import android.support.v4.view.GravityCompat
import android.support.v4.view.ViewPager
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.View
import android.widget.*
import butterknife.ButterKnife
import chat.edu.edu_chat.R.id
import chat.edu.edu_chat.R.layout
import com.instabug.library.Instabug
import com.squareup.picasso.Picasso
import edu_chat.android.com.edu_chat.adapter.main.ViewPagerAdapter
import edu_chat.android.com.edu_chat.controller.LoginActivity
import edu_chat.android.com.edu_chat.controller.chat.CreateChatActivity
import edu_chat.android.com.edu_chat.controller.invite.InviteActivity
import edu_chat.android.com.edu_chat.controller.settings.SettingsActivity
import edu_chat.android.com.edu_chat.controller.userprofile.UserProfileActivity
import edu_chat.android.com.edu_chat.model.CurrentUser
import edu_chat.android.com.edu_chat.view.CircleTransform
import io.swagger.client.ApiCallback
import io.swagger.client.ApiClient
import io.swagger.client.ApiException
import io.swagger.client.Configuration
import io.swagger.client.api.ApiApi
import io.swagger.client.api.ChatApi
import io.swagger.client.api.InstitutionApi
import io.swagger.client.model.*
import kotlinx.android.synthetic.main.main_activity_layout.*

/**
 * This activity will act as a container for the recycler views for the individual chats and
 * classes.
 * Created by Jacob on 10/16/2015.
 */
class MainActivity : AppCompatActivity() {
	internal var hamburgerMenu: ImageView? = null
	internal var drawerLayout: DrawerLayout? = null
	internal var navView: NavigationView? = null
	internal var notificationOne: TextView? = null
	internal var notificationTwo: TextView? = null


	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		this.setContentView(layout.main_activity_layout)
		ButterKnife.setDebug(true)
		ButterKnife.bind(this)

		hamburgerMenu = findViewById<ImageView>(id.hamburger_menu)
		drawerLayout = findViewById<DrawerLayout>(id.drawer_layout_new)
		navView = findViewById<NavigationView>(id.nav_view_new)
		notificationOne = findViewById<TextView>(id.notification_one)
		notificationTwo = findViewById<TextView>(id.notification_two)


		Log.d("Binding", (floatingActionsMenuStudentMainTest == null).toString())
		val tabLayout = findViewById<View>(id.tab_layout) as TabLayout
		tabLayout.addTab(tabLayout.newTab().setCustomView(findViewById<RelativeLayout>(id.tab_classes_view)))
		tabLayout.addTab(tabLayout.newTab().setCustomView(findViewById<RelativeLayout>(id.tab_chats_view)))
		tabLayout.tabGravity = TabLayout.GRAVITY_FILL

		val viewpager = findViewById<View>(id.view_pager) as ViewPager
		viewpager.adapter = ViewPagerAdapter(supportFragmentManager, tabLayout.tabCount)

		this.populateNavDrawer()

		notificationOne!!.visibility = View.INVISIBLE
		notificationTwo!!.visibility = View.VISIBLE
		notificationTwo!!.bringToFront()
		this.getNotificationNumberTwo()



		tabLayout.setSelectedTabIndicatorHeight(8)
		this.populateActionFloatingMenu()
		viewpager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))
		tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
			override fun onTabSelected(tab: TabLayout.Tab) {
				viewpager.currentItem = tab.position
				setNotificationNumber(tab.position)
			}

			override fun onTabUnselected(tab: TabLayout.Tab) {}

			override fun onTabReselected(tab: TabLayout.Tab) {}
		})

	}


	private fun getNotificationNumberOne(){

		notificationOne!!.visibility = View.INVISIBLE

	}


	private fun getNotificationNumberTwo(){

		var count : Int = 0


		ChatApi().chatListAsync(null, null, null, null, null, false,null, object: ApiCallback<ChatListCreateView>{
			override fun onFailure(e: ApiException?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {
				Log.d("F", "F")
			}

			override fun onSuccess(result: ChatListCreateView?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {

				for (n : ChatUnreadSerializer in result!!.results.chats){
					if (n.unreadCount != 0 && n.unreadCount != null)
						count += 1
				}

				runOnUiThread(Runnable { notificationTwo!!.text = count.toString() })
				if (count == 0){
					notificationTwo!!.visibility = View.INVISIBLE
				}
				Log.d("S", "S")


			}

			override fun onUploadProgress(bytesWritten: Long, contentLength: Long, done: Boolean) {

			}

			override fun onDownloadProgress(bytesRead: Long, contentLength: Long, done: Boolean) {

			}


		})


	}

	private fun setNotificationNumber(position : Int) {

		if (position == 0){
			notificationOne!!.visibility = View.INVISIBLE
			notificationTwo!!.visibility = View.VISIBLE
			notificationTwo!!.bringToFront()
		}else{
			notificationOne!!.visibility = View.VISIBLE
			notificationOne!!.bringToFront()
			notificationTwo!!.visibility = View.INVISIBLE
		}
		getNotificationNumberOne()
		getNotificationNumberTwo()


//		notificationTwo!!.text = "2"
	}

//	private fun setNotificationNumber() {
//
//		var unreadChatNumber: Int = 0
//		ChatApi().chatListAsync(null, null, null, null, null, false,null, object: ApiCallback<ChatListCreateView>{
//			override fun onFailure(e: ApiException?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {
//				Log.d("F", "F")
//			}
//
//			override fun onSuccess(result: ChatListCreateView?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {
//
//				for (n : ChatUnreadSerializer in result!!.results.chats){
//					if (n.unreadCount != 0 && n.unreadCount != null)
//						unreadChatNumber += 1
//				}
//
//				notificationTwo!!.text = unreadChatNumber.toString()
//				Log.d("S", "S")
//
//
//			}
//
//			override fun onUploadProgress(bytesWritten: Long, contentLength: Long, done: Boolean) {
//
//			}
//
//			override fun onDownloadProgress(bytesRead: Long, contentLength: Long, done: Boolean) {
//
//			}
//
//		})
//
//
//		notificationTwo!!.bringToFront()
//		notificationTwo!!.visibility = View.VISIBLE
////		notificationTwo!!.text = "2"
//	}





	//    @Override
	//    public boolean onCreateOptionsMenu(Menu menu){
	//        getMenuInflater().inflate(R.menu.main_menu, menu);
	//        return true;
	//    }

	//    @Override
	//    public boolean onOptionsItemSelected (MenuItem menuItem){
	//        int id = menuItem.getItemId();
	//        if(id == R.id.settings_account_and_security){
	//            return super.onOptionsItemSelected(menuItem);
	//        }
	//        return super.onOptionsItemSelected(menuItem);
	//    }

	//        if (savedInstanceState != null) {
	//            final ChatListFragment mChat = (ChatListFragment) this.getSupportFragmentManager().getFragment
	//                    (savedInstanceState, "mChat");
	//        }

	//        this.loadCurrentUserText();
	//        this.setSupportActionBar(this.toolbar);
	//        this.populateNavDrawer();
	//        this.populateActionFloatingMenu();
	//        this.populateSwipeLayout();
	//        this.populateChats();

	//        this.floatingActionsMenu.setOnFloatingActionsMenuUpdateListener(new
	// MyOnFloatingActionsMenuUpdateListener());
	//        this.LLbehindFAB.setOnTouchListener(new OnTouchListener() {
	//            @Override
	//            public boolean onTouch(final View v, final MotionEvent event) {
	//                if (MainActivity.this.floatingActionsMenu.isExpanded()){
	//                    MainActivity.this.floatingActionsMenu.collapse();
	//                    return true;
	//                }
	//                return false;
	//            }
	//        });


	override fun onPostResume() {
		super.onPostResume()
		Log.d("PKAB", "resume")
		//        this.openDrawerOnlyWhileReturning();
	}

//    private fun openDrawerOnlyWhileReturning() {
//        Log.d("PKAB", "here")
//        val prefs = this.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE)
//        val name = prefs.getString("activity", "Default") // "No name defined" is the
//        // default
//        // value.
//        if (name == "Activity") {
//            drawer_layout_new.openDrawer(this.findViewById<View>(id.drawerPane_new))
//            //this.populateNavDrawer()
//            val editor = this.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE)
//                    .edit()
//            editor.remove("activity")
//            editor.apply()
//        }
//    }

	//    @Override
	//    public boolean onCreateOptionsMenu(@NonNull final Menu menu) {
	//        super.onCreateOptionsMenu(menu);
	//        final MenuInflater inflater = this.getMenuInflater();
	//        inflater.inflate(R.menu.main_menu, menu);
	//
	//        final MenuItem item = menu.findItem(id.action_search);
	////        this.searchView.setMenuItem(item);
	//        boolean onCreateOptMenu;
	//        return onCreateOptMenu = true;
	//    }

	private fun populateNavDrawer() {
		this.hamburgerMenu!!.bringToFront()
		this.hamburgerMenu!!.setOnClickListener {
			Log.d("Successful", "clickable")
			this@MainActivity.drawerLayout!!.openDrawer(findViewById<View>(id.drawerPane_new))
		}
		val navigationView = this.findViewById<NavigationView>(id.nav_view_new)
		val headerView = navigationView.getHeaderView(0)
		val navUserPicture = headerView.findViewById<ImageView>(id.nav_user_picture)
		val navUserName = headerView.findViewById<TextView>(id.nav_user_name)
		val navUniversityName = headerView.findViewById<TextView>(id.nav_university_name)

		Picasso.with(this.baseContext)
				.load(CurrentUser.currentUser!!.pictureFile.url)
				.fit()
				.transform(CircleTransform(null))
				.into(navUserPicture)
		navUserName.text = CurrentUser.currentUser!!.firstName + " " + CurrentUser.currentUser!!.lastName
		navUniversityName.text = CurrentUser.currentUser!!.university.toString()
		try {
			InstitutionApi().institutionUniversityListAsync(CurrentUser.currentUser!!.university, null, null, object : ApiCallback<UniversityView> {
				override fun onFailure(e: ApiException?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {
//                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
				}

				override fun onSuccess(result: UniversityView?, statusCode: Int, responseHeaders: MutableMap<String, MutableList<String>>?) {
					runOnUiThread(Runnable { navUniversityName.text = result!!.results!![0]!!.name })
				}

				override fun onDownloadProgress(bytesRead: Long, contentLength: Long, done: Boolean) {
//                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
				}

				override fun onUploadProgress(bytesWritten: Long, contentLength: Long, done: Boolean) {
//                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
				}
			})
		} catch (e: ApiException) {

		}

		this.navView!!.setNavigationItemSelectedListener { item ->

			if (item.itemId == id.nav_profile) {
				val intent = Intent(
						this@MainActivity.baseContext, UserProfileActivity::class.java
				)
				intent.putExtra("user_id", CurrentUser.currentUser!!.id)
				this@MainActivity.startActivity(intent)
			} else if (item.itemId == id.nav_starred) {
				Toast.makeText(this@MainActivity, " browse coming soon!!!", Toast
						.LENGTH_SHORT).show()
			} else if (item.itemId == id.nav_settings) {
				val intent = Intent(
						this@MainActivity.baseContext,
						SettingsActivity::class.java
				)
				intent.putExtra("user_id", CurrentUser.currentUser!!.id)
				this@MainActivity.startActivity(intent)

			} else if (item.itemId == id.nav_feedback) {
				Instabug.invoke()
			} else if (item.itemId == id.nav_logout) {
				this@MainActivity.logOut()
			} else if (item.itemId == id.nav_privacy) {

			} else if (item.itemId == id.nav_acknowledgement) {

			}
			this@MainActivity.drawerLayout!!.closeDrawer(GravityCompat.START)
			true
		}
	}

	/**
	 * Log the user out and return them back to the loginactivity.
	 */
	private fun logOut() {
		//        this.progressDialog = new ProgressDialog(this);
		//        this.progressDialog.setMessage(getString(R.string.logging_out_));
		clearUserData()
		//        this.progressDialog.setIndeterminate(true);
		//        this.progressDialog.show();
		try {
			ApiApi().apiLogoutCreateAsync(object : ApiCallback<LogoutView> {
				override fun onFailure(e: ApiException,
									   statusCode: Int,
									   responseHeaders: Map<String, List<String>>) {
					//System.err.println("error, logout not working");
					Log.d("Logout", "Logout not working")
					Log.d("Logout", e.responseBody)
				}

				override fun onSuccess(result: LogoutView,
									   statusCode: Int,
									   responseHeaders: Map<String, List<String>>) {
					//MainActivity.this.hideProgressDialog();
					//                    MainActivity.this.progressDialog.dismiss();
					this@MainActivity.finish()
					Configuration.setDefaultApiClient(ApiClient())
					val intent = Intent(
							this@MainActivity.applicationContext,
							LoginActivity::class.java
					)
					this@MainActivity.startActivity(intent)
				}

				override fun onUploadProgress(bytesWritten: Long, contentLength: Long, done: Boolean) {

				}

				override fun onDownloadProgress(bytesRead: Long, contentLength: Long, done: Boolean) {

				}
			})
		} catch (e: ApiException) {
			Log.d("Error", "Did not do ApiLogout")
			e.printStackTrace()
		}
	}

	private fun populateActionFloatingMenu() = when (CurrentUser.currentUser!!.type) {
		"f" -> facultyCreate()
		"s" -> studentCreate()
		else -> Toast.makeText(baseContext, "No user type matched!", Toast.LENGTH_SHORT).show()
	}

	private fun facultyCreate() {
		floatingActionsMenuTest.bringToFront()
		create_class_fab.setOnClickListener {
			floatingActionsMenuTest.collapse()
			startActivity(Intent(
					applicationContext,
					InviteActivity::class.java
			))
		}

		create_chat_fab1.setOnClickListener {
			floatingActionsMenuTest.collapse()
			val intent = Intent(
					this@MainActivity.baseContext,
					InviteActivity::class.java
			)
			intent.putExtra("chatType", "chat")
			this@MainActivity.startActivity(intent)
		}

	}

	private fun studentCreate() {
		floatingActionsMenuStudentMainTest.bringToFront()
		create_chat_fab_student.setOnClickListener {
			floatingActionsMenuStudentMainTest.collapse()
			val intent = Intent(
					applicationContext,
					CreateChatActivity::class.java
			)
			intent.putExtra("chatType", "chat")
			closeFAB()

			startActivity(intent)
		}
	}

	fun closeFAB() {
		floatingActionsMenuTest.collapse()
		floatingActionsMenuStudentMainTest.collapse()
	}

	private fun clearUserData() {
		val prefs = getSharedPreferences("login.conf", Context.MODE_PRIVATE)
		val editor = prefs.edit()
		editor.remove("user")
		editor.remove("pass")
		editor.apply()
	}

	override fun onRestart() {
		super.onRestart()
		Log.d("PKAB", "restart")
	}

	override fun onBackPressed() {
		if (this.drawer_layout_new.isDrawerOpen(GravityCompat.START)) {
			this.drawer_layout_new.closeDrawer(GravityCompat.START)
		} else {
			super.onBackPressed()
		}
		Log.d("PKAB", "onback")
	}
}


/*
this.showProgressDialog();
// need to put the progress dialog here
final RequestParams params = new RequestParams();
final LogoutObject logoutObject = new LogoutObject(params) {
	@Override
	public void onFinishGlobal() {
		super.onFinishGlobal();
		final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences
				(MainActivity.this.getApplicationContext());
		final Editor editPrefs = prefs.edit();
		editPrefs.putBoolean("autoLogin", false);
		editPrefs.apply();
		//Once done, return back to LoginActivity.
=======
		}
	})
}
catch (e: ApiException){

}







//        val institution = InstitutionApi()
//        val list = institution.institutionUniversityList(1, null, null)
//
//        navUniversityName.text = list.results.get(0).name




this.navView!!.setNavigationItemSelectedListener { item ->
	val id_temp = item.itemId

	if (id_temp == id.nav_profile) {
		val intent = Intent(
				this@MainActivity.baseContext,
				UserProfileActivity::class.java
		)
		intent.putExtra("user_id", user!!.id)
		this@MainActivity.startActivity(intent)
	} else if (id_temp == id.nav_starred) {
		Toast.makeText(this@MainActivity, " starred coming soon!!!", Toast
				.LENGTH_SHORT).show()
		// Intent intent = new Intent(getBaseContext(), InviteActivity.class);
		// startActivity(intent);


	} else if (id_temp == id.nav_settings) {
		//Toast.makeText(MainActivity.this, "Settings coming soon!!!", Toast
		//        .LENGTH_SHORT).show();
		//  Intent intent = new Intent(getBaseContext(), SettingsActivity.class);
		//  startActivity(intent);
		val intent = Intent(
				this@MainActivity.baseContext,
				SettingsActivity::class.java
		)
		intent.putExtra("user_id", user!!.id)
		this@MainActivity.startActivity(intent)

	} else if (id_temp == id.nav_feedback) {
		Instabug.invoke()
	} else if (id_temp == id.nav_logout) {
		this@MainActivity.logOut()
	} else if (id_temp == id.nav_privacy){

}
else if (id_temp == id.nav_acknowledgement) {
		Toast.makeText(this@MainActivity, " acknowledgement coming soon!!!", Toast
				.LENGTH_SHORT).show()
	}

	//                else if (id == R.id.nav_invite) {
	//                    Intent intent = new Intent(getBaseContext(), InviteActivity.class);
	//                    startActivity(intent);
	//                }
	//                else if (id == R.id.nav_digital_office_hours) {
	//                    Toast.makeText(MainActivity.this," digital office hours coming soon!!! ",
	// Toast.LENGTH_SHORT).show();
	//                   // Intent intent = new Intent(getBaseContext(), DigitalOfficeHoursActivity
	// .class);
	//                    //startActivity(intent);
	//                }
	this@MainActivity.drawerLayout!!.closeDrawer(GravityCompat.START)
	true
}
}

/**
* Log the user out and return them back to the loginactivity.
*/
private fun logOut() {
//        this.progressDialog = new ProgressDialog(this);
//        this.progressDialog.setMessage(getString(R.string.logging_out_));
clearUserData()
//        this.progressDialog.setIndeterminate(true);
//        this.progressDialog.show();
val logOutInst = ApiApi()
try {
	logOutInst.apiLogoutCreateAsync(object : ApiCallback<LogoutView> {
		override fun onFailure(e: ApiException,
							   statusCode: Int,
							   responseHeaders: Map<String, List<String>>) {
			//System.err.println("error, logout not working");
			Log.d("Logout", "Logout not working")
			Log.d("Logout", e.responseBody)
		}

		override fun onSuccess(result: LogoutView,
							   statusCode: Int,
							   responseHeaders: Map<String, List<String>>) {
			//MainActivity.this.hideProgressDialog();
			//                    MainActivity.this.progressDialog.dismiss();
			this@MainActivity.finish()
			Configuration.setDefaultApiClient(ApiClient())
			val intent = Intent(
					this@MainActivity.applicationContext,
					LoginActivity::class.java
			)
			this@MainActivity.startActivity(intent)
		}

		override fun onUploadProgress(bytesWritten: Long, contentLength: Long, done: Boolean) {

		}

		override fun onDownloadProgress(bytesRead: Long, contentLength: Long, done: Boolean) {

		}
	})
} catch (e: ApiException) {
	Log.d("Error", "Did not do ApiLogout")
	e.printStackTrace()
}


/*
this.showProgressDialog();
// need to put the progress dialog here
final RequestParams params = new RequestParams();
final LogoutObject logoutObject = new LogoutObject(params) {
	@Override
	public void onFinishGlobal() {
		super.onFinishGlobal();
		final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences
				(MainActivity.this.getApplicationContext());
		final Editor editPrefs = prefs.edit();
		editPrefs.putBoolean("autoLogin", false);
		editPrefs.apply();
		//Once done, return back to LoginActivity.
>>>>>>> 5eaf5c30ccd55fd1472cb8c175e0a48cbd13f348
//                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);

		final Intent intent = new Intent(
				MainActivity.this.getApplicationContext(),
				LoginActivity.class
		);
		MainActivity.this.hideProgressDialog();
		MainActivity.this.startActivity(intent);
		MainActivity.this.finish();
	}
};
//        logoutObject.invokePost(this);
//        logoutObject.invokePost();
logoutObject.invokePost(MainActivity.this);*/
}


override fun onResume() {
super.onResume()
//        this.drawerLayout.closeDrawer(GravityCompat.START);
//        try {
//            this.getChatLoadOut();
//        } catch (ApiException e) {
//            e.printStackTrace();
//        }
//    }
}




}

/**
* This method will populate ecUserList with the users loaded in from the login call.
*/


//    private void getChatLoadOut() {
//        TODO: Swaggerfy
//        this.swipeContainer.setRefreshing(true);
//        final RequestParams params = new RequestParams();
////        params.put("token", ECUser.getUserToken());
//        final MainLoadOutObject chatObj = new MainLoadOutObject(params) {
//            @Override
//            public void onSuccessGlobal(final int statusCode, final Header[] headers, @NonNull
//            final byte[]
//                    responseBody) {
//                super.onSuccessGlobal(statusCode, headers, responseBody);
//                Log.d("LoadOut_Response", new String(responseBody));
//                MainActivity.this.makeObjectListsFromResponse(super.getObj());
//            }
//
//            @Override
//            public void onFailureGlobal(final int statusCode, final Header[] headers, final
//            byte[] responseBody,
//                                        final Throwable error) {
//                super.onFailureGlobal(statusCode, headers, responseBody, error);
//            }
//
//            @Override
//            public void onFinishGlobal() {
//                super.onFinishGlobal();
//                MainActivity.this.runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        MainActivity.this.populateRecyclerView();
//                    }
//                });
//            }
//        };
//        chatObj.invokeGet(MainActivity.this);


/**
* This method will load the profile picture and the student full name and school.
*/
private fun loadCurrentUserText() {
if (CurrentUser.currentUser!!.pictureFile != null) {
	this.hamburger_menu!!.background = null
	Picasso.with(this)
			.load(CurrentUser.currentUser!!.pictureFile.url)
			//.error(drawable.educhat);
			.resize(
					Constants.GLOBAL_IMAGE_SIZE,
					Constants.GLOBAL_IMAGE_SIZE
			)
			.transform(CircleTransform(null))
			.into(this.hamburger_menu)
	val navigationView = this.findViewById<NavigationView>(id.nav_view_new)
	val headerView = navigationView.getHeaderView(0)
	val navUserPicture = headerView.findViewById<ImageView>(id.nav_user_picture)
	val navUserName = headerView.findViewById<TextView>(id.nav_user_name)

	Picasso.with(this.baseContext)
			.load(CurrentUser.currentUser!!.pictureFile.url)
			.fit()
			.transform(CircleTransform(null))
			.into(navUserPicture)
	val fullName = CurrentUser.currentUser!!.firstName + " " +
			CurrentUser.currentUser!!.lastName
	navUserName.text = fullName
}
}

private fun populateViews() {
this.drawer_layout_new!!.closeDrawer(GravityCompat.START)
}

private fun hideProgressDialog() {
//        if (this.progressDialog != null && this.progressDialog.isShowing()) {
//            this.progressDialog.hide();
//        }
}

private class MyOnFloatingActionsMenuUpdateListener : OnFloatingActionsMenuUpdateListener {
override fun onMenuExpanded() {

}

override fun onMenuCollapsed() {

}
}

val isFABopen: Boolean
get() = floatingActionsMenuTest.isExpanded || floatingActionsMenuStudentMainTest.isExpanded


companion object {
private val MY_PREFS_NAME = "MyPrefsFile"
}

fun onDraw(canvas: Canvas, unread: Int) {
val paint = Paint()
paint.setColor(Color.rgb(254, 142, 56))
canvas.drawRect(10f, 10f, 20f, 20f, paint)
val textPaint = Paint()
textPaint.setColor(Color.WHITE)
textPaint.setTextSize(19f)
canvas.drawText(unread.toString(), 3f, 3f, textPaint)
}

}

*/
