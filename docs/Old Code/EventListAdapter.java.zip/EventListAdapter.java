//package edu_chat.android.com.edu_chat.adapter.chat.chatinfo;
//
//import android.content.Context;
//import android.support.annotation.NonNull;
//import android.support.v7.widget.RecyclerView.Adapter;
//import android.support.v7.widget.RecyclerView.ViewHolder;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.squareup.picasso.Callback;
//import com.squareup.picasso.Picasso;
//import chat.edu.edu_chat.R.drawable;
//import chat.edu.edu_chat.R.id;
//import chat.edu.edu_chat.R.layout;
//
//import java.util.ArrayList;
//
//import edu_chat.android.com.edu_chat.adapter.chat.chatinfo.EventListAdapter.EventHolder;
//import edu_chat.android.com.edu_chat.model.Constants;
//import edu_chat.android.com.edu_chat.view.CircleTransform;
//
///**
// * Created by kkiran on 13/07/16.
// * Edu.Chat Inc.
// */
//
//public class EventListAdapter extends Adapter<EventHolder> {
//
//    private final ArrayList<FileandEventDetailsinGroupChat> list;
//    private final Context context;
//
//    public EventListAdapter(final ArrayList<FileandEventDetailsinGroupChat> listofeventsandfiles,
//                            final Context context) {
//        super();
//        this.list = listofeventsandfiles;
//        this.context = context;
//    }
//
//    @NonNull
//    @Override
//    public EventHolder onCreateViewHolder(@NonNull final ViewGroup parent, final int viewType) {
//        final View view = LayoutInflater.from(parent.getContext()).inflate(
//                layout.item_chat_resource, parent, false);
//        return new EventHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull final EventHolder holder, final int position) {
//        final FileandEventDetailsinGroupChat eventandfile = this.list.get(position);
//        holder.getFileAndEventName().setText(eventandfile.getNameoffile());
//        if (eventandfile.getCommentCount() == 0) holder.getCommentCount().setText("0 Comments");
//        else {
//            if (eventandfile.getCommentCount() == 1) {
//                holder.getCommentCount().setText(eventandfile.getCommentCount() + " Comment");
//            } else {
//                holder.getCommentCount().setText(eventandfile.getCommentCount() + " Comment(s)");
//            }
//        }
//
//        holder.getPostedBy().setText(eventandfile.getPostedBy());
//        holder.getDate().setText(eventandfile.getDateCreated());
//        holder.getImage().setBackground(null);
//        holder.getShortDate().setText(eventandfile.getPostedtime());
//        Picasso.with(this.context)
//                .load(drawable.fileimage)
//                .resize(
//                        Constants.GLOBAL_IMAGE_SIZE,
//                        Constants.GLOBAL_IMAGE_SIZE
//                )
//                .centerInside()
//                .into(holder.getImage(), new Callback() {
//                    @Override
//                    public void onSuccess() {
//                    }
//
//                    @Override
//                    public void onError() {
//                        Picasso.with(EventListAdapter.this.context)
//                                .load(drawable.educhat)
//                                .resize(
//                                        Constants.GLOBAL_IMAGE_SIZE,
//                                        Constants.GLOBAL_IMAGE_SIZE
//                                )
//                                .centerInside()
//                                .transform(new CircleTransform(null))
//                                .into(holder.getImage());
//                    }
//                });
//
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return this.list.size();
//    }
//
//    static class EventHolder extends ViewHolder {
//        private final ImageView image;
//        private final TextView fileAndEventName;
//        private final TextView commentCount;
//        private final TextView postedBy;
//        private final TextView date;
//        private final TextView shortDate;
//
//        EventHolder(@NonNull final View view) {
//            super(view);
//            this.image = view.findViewById(id.imageView);
//            this.fileAndEventName = view.findViewById(id.titleTextView);
//            this.commentCount = view.findViewById(id.commentTextView);
//            this.postedBy = view.findViewById(id.postedByTextView);
//            this.date = view.findViewById(id.dateTextView);
//            this.shortDate = view.findViewById(id.time);
//        }
//
//        public TextView getFileAndEventName() {
//            return this.fileAndEventName;
//        }
//
//        public TextView getCommentCount() {
//            return this.commentCount;
//        }
//
//        public TextView getPostedBy() {
//            return this.postedBy;
//        }
//
//        public TextView getDate() {
//            return this.date;
//        }
//
//        public ImageView getImage() {
//            return this.image;
//        }
//
//        public TextView getShortDate() {
//            return this.shortDate;
//        }
//    }
//}
