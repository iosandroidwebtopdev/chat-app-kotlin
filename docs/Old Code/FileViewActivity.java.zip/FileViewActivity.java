package edu_chat.android.com.edu_chat.controller.chat.viewers;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import chat.edu.edu_chat.R.id;
import chat.edu.edu_chat.R.layout;
import edu_chat.android.com.edu_chat.adapter.chat.viewers.FilePagerAdapter;
import edu_chat.android.com.edu_chat.view.FileViewPager;
import io.swagger.client.model.FileSerializer;

/**
 * Created by yuandali on 7/23/16.
 * Edu.Chat Inc.
 */
public class FileViewActivity extends AppCompatActivity {

    @Nullable @BindView(id.comment_button) LinearLayout commentButton;
    @Nullable @BindView(id.share_button) LinearLayout shareButton;
    @Nullable @BindView(id.download_button) LinearLayout downloadButton;
    @Nullable @BindView(id.view_pager) FileViewPager fileViewPager;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(layout.activity_file_view);
        final Toolbar toolbar = this.findViewById(id.file_view_toolbar);
        this.setSupportActionBar(toolbar);
        ButterKnife.bind(this);
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        this.setViews();
    }

    private void setViews() {
        this.commentButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                Toast.makeText(FileViewActivity.this.getBaseContext(), "Comment", Toast
                        .LENGTH_SHORT).show();
            }
        });

        this.shareButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                Toast.makeText(FileViewActivity.this.getBaseContext(), "Share", Toast
                        .LENGTH_SHORT).show();
            }
        });

        this.downloadButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                Toast.makeText(FileViewActivity.this.getBaseContext(), "Download", Toast
                        .LENGTH_SHORT).show();
            }
        });

        final List<FileSerializer> fileList = new ArrayList<>();
        fileList.add(new FileSerializer());
        fileList.add(new FileSerializer());
        fileList.add(new FileSerializer());
        fileList.add(new FileSerializer());
        final FilePagerAdapter filePagerAdapter = new FilePagerAdapter(fileList);
        this.fileViewPager.setAdapter(filePagerAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
//        this.getMenuInflater().inflate(R.menu.file_view_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull final MenuItem item) {
        final int itemId = item.getItemId();
//        TODO: Fix
//        if (itemId == R.id.home) {
//            super.onBackPressed();
//        } else if (itemId == id.copy) {
//            Toast.makeText(this.getBaseContext(), "Copy", Toast.LENGTH_SHORT).show();
//        } else if (itemId == id.edit) {
//            Toast.makeText(this.getBaseContext(), "Edit", Toast.LENGTH_SHORT).show();
//        } else if (itemId == id.delete) {
//            Toast.makeText(this.getBaseContext(), "Delete", Toast.LENGTH_SHORT).show();
//        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public String toString() {
        return "FileViewActivity{" +
                "commentButton=" + this.commentButton +
                ", shareButton=" + this.shareButton +
                ", downloadButton=" + this.downloadButton +
                ", fileViewPager=" + this.fileViewPager +
                "} " + super.toString();
    }
}
