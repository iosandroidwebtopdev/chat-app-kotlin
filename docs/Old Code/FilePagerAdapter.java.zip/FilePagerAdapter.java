package edu_chat.android.com.edu_chat.adapter.chat.viewers;

import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;
import java.util.Objects;

import io.swagger.client.model.FileSerializer;

/**
 * Created by yuandali on 7/23/16.
 * Edu.Chat Inc.
 */
public class FilePagerAdapter extends PagerAdapter {

    private final List<FileSerializer> fileList;

    public FilePagerAdapter(final List<FileSerializer> fileList) {
        super();
        this.fileList = fileList;
    }

    @Override
    public int getCount() {
        return this.fileList.size();
    }

    @NonNull
    @Override
    public View instantiateItem(@NonNull final ViewGroup container, final int position) {
//        if (this.fileList.get(position) == ECFileType.ECFileImageType) {
//            final PhotoView photoView = new PhotoView(container.getContext());
//            photoView.setImageResource(this.fileList.get(position).getFileSource());
//            container.addView(photoView, LayoutParams.MATCH_PARENT,
//                              LayoutParams.MATCH_PARENT
//            );
//            return photoView;
//        } else if (this.fileList.get(position).getFileType() == ECFileType.ECFilePDFType) {
//            final TextView textView = new TextView(container.getContext());
//            textView.setText("This is a PDF file.\nPreview will be available soon.");
//            textView.setTextColor(Color.parseColor("#FFFFFF"));
//            textView.setGravity(Gravity.CENTER);
//            container.addView(textView, LayoutParams.MATCH_PARENT,
//                              LayoutParams.MATCH_PARENT
//            );
//            return textView;
//        } else {
//            final TextView textView = new TextView(container.getContext());
//            textView.setText("Unknown file type.");
//            textView.setGravity(Gravity.CENTER);
//            container.addView(textView, LayoutParams.MATCH_PARENT,
//                              LayoutParams.MATCH_PARENT
//            );
//            return textView;
//        }
        return null;
    }

    @Override
    public void destroyItem(@NonNull final ViewGroup container, final int position, final Object
            object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(final View view, final Object object) {
        return Objects.equals(view, object);
    }
}
