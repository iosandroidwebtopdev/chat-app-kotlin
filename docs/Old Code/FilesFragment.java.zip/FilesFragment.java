package edu_chat.android.com.edu_chat.controller.chat.chatinfo;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionButton;
import chat.edu.edu_chat.R.id;
import chat.edu.edu_chat.R.layout;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import edu_chat.android.com.edu_chat.adapter.chat.chatinfo.ChatResourceAdapter;
import edu_chat.android.com.edu_chat.model.ChatResource;
import edu_chat.android.com.edu_chat.view.DividerItemDecoration;

/**
 * Created by yuandali on 6/20/16.
 * Edu.Chat Inc.
 */
public class FilesFragment extends Fragment {

    @Nullable
    @BindView(id.fileslistview) RecyclerView filesListView;
    @Nullable
    @BindView(id.addfile) FloatingActionButton addFile;

    private Context context;
    // --Commented out by Inspection (9/2/16, 4:18 PM):private Hashtable<String, ECUser> userTable;

    @Override
    public void onAttach(final Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {
        final View view = inflater.inflate(layout.fragment_files, container, false);
        ButterKnife.bind(this, view);
        this.addFile.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(final View v) {
                Toast.makeText(FilesFragment.this.getActivity(), "Coming Soon!!", Toast
                        .LENGTH_SHORT).show();
            }
        });

        this.updateListView();

        return view;
    }

    private void updateListView() {
       // final List<ChatResource> fileList = ((ChatinfoActivity) this.getActivity()).getFileList();
//        final ChatResourceAdapter filesListAdapter = new ChatResourceAdapter(
//                this.getActivity(),
//                fileList
//        );

        this.filesListView.setHasFixedSize(true);
        this.filesListView.invalidate();
        this.filesListView.setLayoutManager(new LinearLayoutManager(this.context));
        this.filesListView.addItemDecoration(new DividerItemDecoration(this.context));
        //this.filesListView.setAdapter(filesListAdapter);
    }
}
