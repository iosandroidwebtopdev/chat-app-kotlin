package edu_chat.android.com.edu_chat.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.swagger.client.model.UserSerializer;

/**
 * Created by yuandali on 8/28/16.
 * Edu.Chat Inc.
 */

public class ChatFileResource extends ChatResource {

    public ChatFileResource(final int id, final JSONObject obj, final UserSerializer author) {
        super();

        try {
            // Set title
            this.title = obj.getString("original_name");
            // Set date
            this.setCreated(obj.getString("created"));
            final String dateString = obj.getString("created");
            try {
                final SimpleDateFormat sdfIn = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                final Date inDate = sdfIn.parse(dateString.replace("T", " "));

                this.date = new SimpleDateFormat("MMM dd, yyyy").format(inDate);
            } catch (final ParseException e) {
                e.printStackTrace();
                this.date = obj.getString("created");
            } catch (final RuntimeException e) {
                e.printStackTrace();
            }
            // Set postBy
            if (author != null) {
                this.postedBy = "Posted by " + author.getFirstName();
            }
            // Set extention
            this.setInfo(obj.getString("file_extension").toUpperCase());
        } catch (final JSONException e) {
            e.printStackTrace();
        }


    }
}
