package urlinq.android.com.edu_chat.model;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

import urlinq.android.com.edu_chat.model.enums.ECMessageType;

import static org.junit.Assert.assertEquals;

/**
 * Created by muthu on 6/15/2016.
 */
public class UnitTestforECMessage {
    ECMessage msg;
    ECUser usr;

    //private String json_msg = "{\"edited\":false,\"user_id\":59974,\"sent_at\":\"2016-06-09T19:07:28\",\"text\":\"Hey\",\"object_type\":null,\"subchannel_id\":null,\"target_type\":\"user\",\"object_id\":null,\"target_id\":59984,\"user\":{\"closed_showcase_instructions\":null,\"net_id\":null,\"user_type\":\"o\",\"last_activity\":\"2016-06-15T14:45:13\",\"last_email\":\"2016-06-15T14:30:17\",\"id\":59974,\"show_edit_profile_post\":null,\"name_abbreviation\":\"Mr.\",\"notification_method_push_notifications\":false,\"department\":null,\"notification_frequency\":\"front_row\",\"show_fbar_tutorial\":null,\"available\":null,\"firstname\":\"Ross\",\"lastname\":\"Kopelman\",\"timezone_offset\":240,\"show_profile_tutorial\":null,\"picture_file\":{\"file_source\":\"regular\",\"user_id\":null,\"origin_id\":null,\"file_type\":\"jpg\",\"file_name\":\"R5A5DA9\",\"file_extension\":\"jpg\",\"original_name\":\"R5A5DA9\",\"file_url\":\"/assets/profile_image/R5A5DA9.jpg\",\"subchannel_id\":null,\"file_description\":\"\",\"created_timestamp\":\"2016-02-08T00:56:19\",\"download_count\":0,\"id\":6039,\"origin_type\":null,\"size\":0},\"school\":null,\"name\":\"Ross Kopelman\",\"type\":\"user\",\"university\":5001,\"notification_method_emails\":true,\"show_planner_tutorial\":null,\"status\":\"unverified\",\"user_bio\":\"\",\"notification_method_desktop_notifications\":false,\"user_email\":\"ross@edu.chat\"},\"type\":\"text\",\"id\":9798,\"target\":{\"closed_showcase_instructions\":null,\"net_id\":null,\"user_type\":\"s\",\"last_activity\":\"2016-06-16T13:22:27\",\"last_email\":\"2016-06-15T14:30:17\",\"id\":59984,\"show_edit_profile_post\":null,\"name_abbreviation\":null,\"notification_method_push_notifications\":false,\"department\":null,\"notification_frequency\":\"front_row\",\"show_fbar_tutorial\":null,\"available\":null,\"firstname\":\"Muthukumaran\",\"lastname\":\"PK\",\"timezone_offset\":null,\"show_profile_tutorial\":null,\"picture_file\":5965,\"school\":null,\"name\":\"Muthukumaran PK\",\"type\":\"user\",\"university\":1,\"notification_method_emails\":true,\"show_planner_tutorial\":null,\"status\":\"unverified\",\"user_bio\":\"\",\"notification_method_desktop_notifications\":false,\"user_email\":\"mp4155@nyu.edu\"}}";
//    private String json_user = "{\"closed_showcase_instructions\":null,\"net_id\":null,\"user_type\":\"o\",\"last_activity\":\"2016-06-15T14:45:13\",\"last_email\":\"2016-06-15T14:30:17\",\"id\":59974,\"show_edit_profile_post\":null,\"name_abbreviation\":\"Mr.\",\"notification_method_push_notifications\":false,\"department\":null,\"notification_frequency\":\"front_row\",\"show_fbar_tutorial\":null,\"available\":null,\"firstname\":\"Ross\",\"lastname\":\"Kopelman\",\"timezone_offset\":240,\"show_profile_tutorial\":null,\"picture_file\":{\"file_source\":\"regular\",\"user_id\":null,\"origin_id\":null,\"file_type\":\"jpg\",\"file_name\":\"R5A5DA9\",\"file_extension\":\"jpg\",\"original_name\":\"R5A5DA9\",\"file_url\":\"/assets/profile_image/R5A5DA9.jpg\",\"subchannel_id\":null,\"file_description\":\"\",\"created_timestamp\":\"2016-02-08T00:56:19\",\"download_count\":0,\"id\":6039,\"origin_type\":null,\"size\":0},\"school\":null,\"name\":\"Ross Kopelman\",\"type\":\"user\",\"university\":5001,\"notification_method_emails\":true,\"show_planner_tutorial\":null,\"status\":\"unverified\",\"user_bio\":\"\",\"notification_method_desktop_notifications\":false,\"user_email\":\"ross@edu.chat\"}";
//
    @Before
    public void setUp() throws Exception {
            JSONObject json_u = new JSONObject("{\"id\":3,\"picture_file\":{\"id\":3,\"file_url\":\"https:\\/\\/s3.amazonaws.com\\/edu.chat\\/spongebob.jpg\"},\"user_email\":\"admin@urlinq.com\",\"firstname\":\"Urlinq\",\"lastname\":\"Admin\",\"last_activity\":\"2016-07-21T19:23:31.377109\"}");
//        JSONObject json_m = new JSONObject(json_msg);
//        msg = new ECMessage(json_m);

       // JSONObject json_u = new JSONObject(json_user);
        usr = new ECUser(json_u);

    }

    @Test
    public void TestMessageTitle() throws Exception {
        assertEquals("Hey", msg.getMessageTitle());
    }

    @Test
    public void TestAuthor() throws Exception{
        //assertEquals(usr, msg.getAuthor());

    }

    @Test
    public void TestMessageDate() throws Exception{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        assertEquals(format.parse("2016-06-09T19:07:28".replace("T", " ")),msg.getMessageDate());

    }


    @Test
    public void TestMessageType() throws Exception{
        assertEquals(ECMessageType.ECMessageTextType, msg.getMessageType());


    }
}
