package edu_chat.android.com.edu_chat.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.swagger.client.model.UserSerializer;

/**
 * Created by yuandali on 8/28/16.
 * Edu.Chat Inc.
 */

public class ChatEventResource extends ChatResource {

//    public ChatEventResource(final int id) {
//        super(id);
//    }

    public ChatEventResource(final int id, final JSONObject obj, final UserSerializer author) {
        super();

        try {
            this.title = obj.getString("title");
            this.setCreated(obj.getString("created"));

            // Set postedBy
            if (author != null) {
                this.postedBy = "Posted by " + author.getFirstName();
            }

            this.date = obj.getString("created");
            final String startDay = obj.getString("start_date");
            final String endDay = obj.getString("end_date");
            final String startTime = obj.getString("start_time");
            final String endTime = obj.getString("end_time");
            final SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
            final Date dStartTime = sdfTime.parse(startTime);
            final Date dEndTime = sdfTime.parse(endTime);
            final SimpleDateFormat sdfDay = new SimpleDateFormat("yyyy-mm-dd");
            final Date dStartDay = sdfDay.parse(startDay);
            final Date dEndDay = sdfDay.parse(endDay);
            final SimpleDateFormat sdfOut = new SimpleDateFormat("h:mm a");
            if (startDay.equals(endDay)) {
                this.date = sdfOut.format(dStartTime) + " - " + sdfOut.format(dEndTime);
            } else {
                final SimpleDateFormat sdfDayOut = new SimpleDateFormat("MMM dd");
                this.date = sdfOut.format(dStartTime) + sdfDayOut.format(dStartDay)
                        + " - " + sdfOut.format(dEndTime) + sdfDayOut.format(dEndDay);
            }
            final SimpleDateFormat sdfDayInfo = new SimpleDateFormat("MMM\ndd");
            this.info = sdfDayInfo.format(dStartDay);
        } catch (final JSONException | ParseException e) {
            e.printStackTrace();
        }
    }
}
