package edu_chat.android.com.edu_chat.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import chat.edu.edu_chat.R.color;
import chat.edu.edu_chat.R.id;
import chat.edu.edu_chat.R.layout;
import io.swagger.client.model.UserSerializer;

/**
 * Created by kkiran on 20/07/16.
 * Edu.Chat Inc.
 */

class SpinnerAdapterforSubChat extends ArrayAdapter<UserSerializer> {
//public class SpinnerAdapterforSubChat extends ArrayAdapter<Object> {

    //        private List<String> objects;
    private final List<UserSerializer> subchats;
    //        private List<Object> subchats;
    private final Context context;

    public SpinnerAdapterforSubChat(final Context context, final int resourceId,

                                    @NonNull final List<UserSerializer> subchats) {
//                                  List<Object> subchats) {
        super(context, resourceId, subchats);
//            super(context, resourceId);
//            this.objects = objects;
        this.subchats = subchats;
        this.context = context;
    }

    @Override
    public String toString() {
        return "SpinnerAdapterforSubChat{" +
                "subchats=" + this.subchats +
                ", context=" + this.context +
                "} " + super.toString();
    }    @NonNull @SuppressWarnings("deprecation")
    @Override
    public View getView(final int position, final View convertView, final ViewGroup parent) {
        final LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context
                                                                                               .LAYOUT_INFLATER_SERVICE);
        final View row = convertView == null ? inflater.inflate(
                layout.spinner_item_list,
                parent,
                false
        ) : convertView;
        final TextView label = row.findViewById(id.rowinSpinner);
        label.setText(this.subchats.get(position).getFirstName());

        if (position == 0) {//Special style for dropdown header
            label.setTextColor(this.context.getResources().getColor(color.text_hint_color));
            row.setBackgroundColor(this.context.getResources().getColor(color
                                                                                .toolbarBlackTransparent));
        }
        return row;
    }


    @Override
    public View getDropDownView(final int position, final View convertView,
                                final ViewGroup parent) {
        return this.getView(position, convertView, parent);
    }


}

